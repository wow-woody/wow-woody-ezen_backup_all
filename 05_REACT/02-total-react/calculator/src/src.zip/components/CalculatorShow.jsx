import React, { useContext } from 'react'
import { CalculatorContext } from '../context/CalculatorContext'

const CalculatorShow = () => {
    const { input } = useContext(CalculatorContext); // Context에서 상태 변수 가져오기
    return (
        <div>
            <div className='display'>{input}</div>
        </div>
    )
}

export default CalculatorShow
