import React, { useState } from 'react'
import { CalculatorContext } from '../context/CalculatorContext'

const Calculator = () => {

  // 계산기에 보여지는 영역 - 상태 변수
  const [input, setInput] = useState('');

  // 계산기 버튼을 클릭하면 보여질 영역 - 이벤트 핸들러
  const handleClick = () => {

  }

  return (
    <CalculatorContext.Provider value={{ input, setInput, handleClick }}>
    

    <div>
      
    </div>
    </CalculatorContext.Provider>
  
  )
}

export default Calculator
