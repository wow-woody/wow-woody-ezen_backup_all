import React from 'react'
import Title from '../components/Title'
import ProductListPage from './ProductListPage'
import SearchInput from '../components/SearchInput'

const Subpage = ({ title, category, banner }) => {
    return (
        <div className='sub-page'>
            <div className="sub-banner">
                {banner ? <img src={banner} alt={title} /> : ""}
            </div>
            <Title title={title} />
            <SearchInput />
            <ProductListPage category={category} />
        </div>
    )
}
export default Subpage