import React, { useEffect } from 'react'
import Subpage from './Subpage'
import { useAuthStore } from '../store/authStore'

const Man = () => {
  const { clearSearch } = useAuthStore();

  useEffect(() => {
    clearSearch();
  }, [])

  return (
    <div className='sub-page-wrap'>
      <Subpage title="남자"
        category="men's clothing"
        banner="./images/man-sub-banner.jpg" />
    </div>
  )
}



export default Man