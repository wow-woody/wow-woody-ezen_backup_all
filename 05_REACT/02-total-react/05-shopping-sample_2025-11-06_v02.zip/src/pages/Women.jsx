import React, { useEffect } from 'react'
import Subpage from './Subpage'
import { useAuthStore } from '../store/authStore';

const Women = () => {
  const { clearSearch } = useAuthStore();

  useEffect(() => {
    clearSearch();
  }, [])
  
  return (
    <div className='sub-page-wrap'>
      <Subpage title="여자"
        category="women's clothing"
        banner="./images/women-sub-banner.jpg" />
    </div>
  )
}

export default Women