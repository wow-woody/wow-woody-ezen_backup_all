import React, { useEffect } from 'react'
import Subpage from './Subpage'
import { useAuthStore } from '../store/authStore';

const Electronics = () => {
  const { clearSearch } = useAuthStore();

  useEffect(() => {
    clearSearch();
  }, [])

  return (
    <div className='sub-page-wrap'>
      <Subpage title="전자제품"
        category="electronics"
        banner="./images/electronics-sub-banner.jpg" />
    </div>
  )
}

export default Electronics