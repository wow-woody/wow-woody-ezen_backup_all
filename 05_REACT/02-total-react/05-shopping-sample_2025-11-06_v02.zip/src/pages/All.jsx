import Subpage from './Subpage'

const All = () => {
  
    return (
        <div className='sub-page-wrap'>
            <Subpage title="페이징연습"
                category=""
                banner=""
            />
        </div>
    )
}

export default All