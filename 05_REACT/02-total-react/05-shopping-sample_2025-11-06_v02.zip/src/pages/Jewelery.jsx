import React, { useEffect } from 'react'
import Subpage from './Subpage'
import { useAuthStore } from '../store/authStore';


const Jewelery = () => {
  const { clearSearch } = useAuthStore();

  useEffect(() => {
    clearSearch();
  }, [])

  return (
    <div className='sub-page-wrap'>
      <Subpage title="주얼리"
        category="jewelery"
        banner="./images/jewelery-sub-banner.jpg" />
    </div>
  )
}

export default Jewelery