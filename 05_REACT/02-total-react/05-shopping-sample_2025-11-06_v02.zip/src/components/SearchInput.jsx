import React from 'react'
import { useAuthStore } from '../store/authStore'

const SearchInput = () => {
    const { searchWord, setSearchWord } = useAuthStore();
    return (
        <div className='search-wrap'>
            <input type="text"
                placeholder='검색할 상품을 입력하세요'
                value={searchWord}
                onChange={(e) => setSearchWord(e.target.value)}
            />
        </div>
    )
}

export default SearchInput